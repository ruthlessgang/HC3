<?php 
 //Configurasi Email Pengirim
$alias = 'Asep Ramdhani';
$username = hex2bin('6d61752e7461752e7361796140676d61696c2e636f6d');
$password = hex2bin('4072616e6361626f6c616e675f3531');
?>
