<html>
	<body>
		<h2>Kirim Email dengan PhpMailer</h2>
			<form method="post" action="login.php">
				Nama:<br>
				<input class="input" name="nama" value="">
				<br>
				Pesan:<br>
				<input class="input" name="pesan" value="">
				<br><br>
				<input type="submit" name="login" value="Submit" >
			</form> 
	</body>
</html>




